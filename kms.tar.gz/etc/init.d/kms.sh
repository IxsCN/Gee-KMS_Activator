#!/bin/sh /etc/rc.common
# Copyright (C) 2016 evenS

START=60
STOP=60

set_DNS() {
	echo "srv-host=_vlmcs._tcp,hiwifi.com,1688,100,100" > /tmp/dnsmasq.d/kms.conf
	/etc/init.d/dnsmasq reload
}

del_DNS() {
	rm -rf /tmp/dnsmasq.d/kms.conf
	/etc/init.d/dnsmasq reload
}

start()
{
	/usr/sbin/vlmcsd -D &
	set_DNS	
}

stop()
{
	del_DNS
	ps | grep /usr/sbin/vlmcsd | grep -v 'grep' | awk '{print $1}' |xargs kill -9
}